# S4 asset listing

One `.zone` file for each S4 1.14 fastfile. Each file lists `type,name` rows. Use a file to find the zone of an asset without a dump.

Source: S4 1.14 CASC storage, `listzone --all`, 2026-11-26.

Result: 3746 of 3746 zones. Seventeen zones hold no assets, and their files are empty.
