const fs = require('fs')
const files = fs.readdirSync('.')

const techsets = {}
for (const file of files)
{
    const data = fs.readFileSync(file).toString()
    const lines = data.split('\n')
    for (const line of lines)
    {
        if (line.startsWith('techset,') && !line.startsWith('techset,,'))
        {
            const techset = line.slice('techset,'.length)
            techsets[techset] = true
        }
    }
}

fs.writeFileSync('techsets.json', JSON.stringify(Object.keys(techsets), null, 4))
