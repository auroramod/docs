# IW8 asset listing

One `.zone` file for each IW8 1.20 fastfile. Each file lists `type,name` rows. Use a file to find the zone of an asset without a dump.

Source: IW8 1.20 CASC storage, `listzone --all`, 2026-11-15.

Result: 9472 of 9494 zones. Twenty-two zones do not pass the container check:

```text
english\eng_mp_frontend.ff
english\eng_mp_frontend1.ff
english\eng_mp_frontend2.ff
japan\jp_mp_frontend.ff
japan\jp_mp_frontend1.ff
japan\jp_mp_frontend2.ff
korea15\kr15_mp_frontend.ff
korea15\kr15_mp_frontend1.ff
korea15\kr15_mp_frontend2.ff
mp_frontend.ff
mp_frontend1.ff
mp_frontend2.ff
mp_infil_br_ending_chopper_tr.ff
saudiarabia\sa_mp_frontend.ff
saudiarabia\sa_mp_frontend1.ff
saudiarabia\sa_mp_frontend2.ff
techsets_mp_frontend.ff
techsets_mp_frontend1.ff
techsets_mp_frontend2.ff
worldwide\ww_mp_frontend.ff
worldwide\ww_mp_frontend1.ff
worldwide\ww_mp_frontend2.ff
```

The frontend zones use an older xfile version. `mp_infil_br_ending_chopper_tr` also uses an older xfile version.
